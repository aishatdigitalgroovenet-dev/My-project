import { PLANS, CHORD_ORDER, totalChapters, matrixOf, arcLabel, validateArc } from "../src/config/plans.ts";
import { parseSyntax, formatSyntax } from "../src/lib/dhm/syntax.ts";
import { auditDhm } from "../src/lib/dhm/audit.ts";
import type { DhmDocument } from "../src/lib/dhm/types.ts";
import assert from "node:assert/strict";

// Plans
const exp = { basic: [1,3,1,5,3,3,59,1], standard: [2,3,2,7,3,3,79,2], founding: [3,4,2,9,4,3,199,3] } as const;
for (const [id, e] of Object.entries(exp)) {
  const p = PLANS[id as keyof typeof PLANS];
  assert.deepEqual([...CHORD_ORDER.map(k => p.arc[k]), totalChapters(p.arc), matrixOf(p.arc).rows, matrixOf(p.arc).cols, p.priceUsd, p.revisedWishes], [...e], id);
  console.log("plan ok", id, arcLabel(p.arc), `${matrixOf(p.arc).rows}x${matrixOf(p.arc).cols}`);
}
assert.equal(validateArc(PLANS.founding, { awareness: 4, resolution: 3, callToAction: 2 }).length, 0);
assert.ok(validateArc(PLANS.founding, { awareness: 4, resolution: 4, callToAction: 2 }).length > 0);
assert.ok(validateArc(PLANS.founding, { awareness: 0, resolution: 7, callToAction: 2 }).length > 0);
assert.ok(validateArc(PLANS.basic, { awareness: 2, resolution: 2, callToAction: 1 }).length > 0);

// Syntax
const s = parseSyntax("SYA+ ASA+ YAA")!;
assert.equal(formatSyntax(s), "SYA + ASA + YAA");
assert.equal(parseSyntax("SYX"), null);
assert.equal(parseSyntax("SY"), null);

// Audit
const mk = (n: number, main: string, adv: string[], syn: string) => ({ id: String(n), number: n, title: "", mainSentence: main, syntax: parseSyntax(syn)!, mainAdvice: adv, subheadings: [] });
const doc: DhmDocument = { chords: [
  { key: "awareness", chapters: [mk(1, "Thesis", [], "SYA+ASA+YAA"), mk(2, "", ["do x"], "SYA+SYA+SYA")] },
  { key: "resolution", chapters: [mk(3, "T3", ["a"], "SYA+SYA+SYA"), mk(4, "T4", ["a"], "SYA+SYA+SYA")] },
] };
const r = auditDhm(doc);
const has = (rule: string, ch?: number) => r.findings.some(f => f.rule === rule && (ch === undefined || f.chapter === ch));
assert.ok(has("helix_gap", 1)); assert.ok(has("helix_gap", 2)); assert.ok(has("sot_chain", 2)); assert.ok(has("syntax_clash"));
assert.ok(!has("helix_gap", 3));
doc.chords[0].chapters[0].subheadings.push({ id: "s", title: "T", subSentence: "x", points: [{ id: "p", microSentence: "", syntax: ["S","Y","A"], components: [{kind:"S",content:"story"},{kind:"Y",content:""},{kind:"A",content:"adv"}] }] });
const r2 = auditDhm(doc);
assert.ok(r2.findings.some(f => f.rule === "missing_say" && /Yielded Evidence/.test(f.message)));
assert.ok(r2.findings.some(f => f.rule === "missing_say" && /Micro-Sentence/.test(f.message)));
console.log("syntax + audit ok;", r2.findings.length, "findings;", r.manualReview.length, "manual-review items");
