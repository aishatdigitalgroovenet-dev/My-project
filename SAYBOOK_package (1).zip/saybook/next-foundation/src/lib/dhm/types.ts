import type { ChordKey } from "../../config/plans";
import type { ChapterSyntax, SayElement, SayString } from "./syntax";

// Hierarchy: Book -> Chord -> Chapter -> Subheading -> SAY Point -> Story / Yielded Evidence / Advice
export interface SayComponent { kind: SayElement; content: string }

export interface SayPoint {
  id: string;
  microSentence: string;          // client's "Micro-Sentence"; the outline stays short, no 200-300 word drafting
  syntax: SayString;              // slot order for this point (defaults from the chapter syntax)
  components: SayComponent[];     // one per slot, same order as `syntax`
}

export interface Subheading {
  id: string;
  title: string;
  subSentence: string;
  points: SayPoint[];
}

export interface Chapter {
  id: string;
  number: number;
  title: string;
  mainSentence: string;           // Story of Thesis "Main Sentence" (the chapter's verdict)
  syntax: ChapterSyntax;          // e.g. SYA + ASA + YAA
  mainAdvice: string[];           // Grand Advice: Main Advice Statements
  subheadings: Subheading[];
}

export interface Chord { key: ChordKey; chapters: Chapter[] }
export interface DhmDocument { chords: Chord[] }
