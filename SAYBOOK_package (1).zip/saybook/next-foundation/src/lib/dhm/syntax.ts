// SAY syntax as structured data, never an opaque string.
// S = Story, Y = Yielded Evidence, A = Advice.
export type SayElement = "S" | "Y" | "A";
export type SayString = readonly [SayElement, SayElement, SayElement];
export type ChapterSyntax = readonly SayString[];

export const SAY_LABEL: Record<SayElement, string> = {
  S: "Story",
  Y: "Yielded Evidence",
  A: "Advice",
};

/** Client examples: SYA (story-led), ASA (advice-led), YAA (evidence-led). Presets only; any S/Y/A triple is accepted. */
export const SAY_PRESETS: readonly SayString[] = [
  ["S", "Y", "A"],
  ["A", "S", "A"],
  ["Y", "A", "A"],
];

const isEl = (c: string): c is SayElement => c === "S" || c === "Y" || c === "A";

/** "SYA+ ASA+ YAA" becomes [[S,Y,A],[A,S,A],[Y,A,A]]. Returns null when invalid. */
export function parseSyntax(input: string): ChapterSyntax | null {
  const parts = input.toUpperCase().split("+").map((p) => p.trim()).filter(Boolean);
  if (parts.length === 0) return null;
  const out: SayString[] = [];
  for (const p of parts) {
    const c = [...p];
    if (c.length !== 3 || !c.every(isEl)) return null;
    out.push([c[0], c[1], c[2]] as unknown as SayString);
  }
  return out;
}

export const formatSyntax = (s: ChapterSyntax): string => s.map((x) => x.join("")).join(" + ");
export const syntaxKey = (s: ChapterSyntax): string => s.map((x) => x.join("")).join("+");
