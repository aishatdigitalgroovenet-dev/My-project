import type { DhmDocument, Chapter } from "./types";
import { syntaxKey } from "./syntax";

export type Severity = "error" | "warning" | "info";
export type AuditRule = "helix_gap" | "syntax_clash" | "missing_say" | "sot_chain" | "arc_alignment";

export interface Finding {
  rule: AuditRule;
  severity: Severity;
  chapter?: number;
  message: string;
  hint: string;
}

const blank = (s: string | undefined) => !s || s.trim().length === 0;

/**
 * Rule-based structural checks. They test whether required fields are populated and whether
 * syntax varies. They do NOT judge whether an argument is logically coherent or whether a
 * sentence belongs to the right ARC stage; those are returned as `manualReview` for the author.
 */
export function auditDhm(doc: DhmDocument): { findings: Finding[]; manualReview: string[] } {
  const findings: Finding[] = [];
  const chapters: Chapter[] = doc.chords.flatMap((c) => c.chapters);

  for (const ch of chapters) {
    const n = ch.number;
    const hasAdvice = ch.mainAdvice.some((a) => !blank(a));
    // 1. Gaps in the Helix
    if (!blank(ch.mainSentence) && !hasAdvice)
      findings.push({ rule: "helix_gap", severity: "error", chapter: n,
        message: `Chapter ${n} has a Story of Thesis but no Main Advice Statement.`,
        hint: "Add at least one Main Advice Statement so the helix is not unzipped." });
    if (blank(ch.mainSentence) && hasAdvice)
      findings.push({ rule: "helix_gap", severity: "warning", chapter: n,
        message: `Chapter ${n} has Main Advice but no Story of Thesis sentence.`,
        hint: "Write the chapter's Main Sentence (its verdict)." });

    // 4. SOT chain completeness
    if (blank(ch.mainSentence))
      findings.push({ rule: "sot_chain", severity: "error", chapter: n,
        message: `The SOT chain has a gap at chapter ${n}: no Main Sentence.`,
        hint: "Every chapter needs a Main Sentence before the chain can be read top to bottom." });

    for (const sub of ch.subheadings) {
      if (blank(sub.subSentence))
        findings.push({ rule: "sot_chain", severity: "warning", chapter: n,
          message: `Chapter ${n}, subheading "${sub.title || "untitled"}" has no Sub-Sentence.`,
          hint: "Sub-Sentences link the Main Sentence to the Micro-Sentences." });
      // 5. Missing SAY elements
      sub.points.forEach((p, i) => {
        if (blank(p.microSentence))
          findings.push({ rule: "missing_say", severity: "warning", chapter: n,
            message: `Chapter ${n}, "${sub.title || "untitled"}", point ${i + 1}: no Micro-Sentence.`,
            hint: "Add the one-line sentence this SAY point must prove." });
        p.syntax.forEach((el, slot) => {
          if (blank(p.components[slot]?.content))
            findings.push({ rule: "missing_say", severity: "warning", chapter: n,
              message: `Chapter ${n}, "${sub.title || "untitled"}", point ${i + 1}: ${
                el === "S" ? "Story" : el === "Y" ? "Yielded Evidence" : "Advice"} (slot ${slot + 1}) is empty.`,
              hint: "Outline it in a short note; full 200-300 word writing comes later." });
        });
      });
    }
  }

  // 2. Syntax clashes
  if (chapters.length >= 2 && new Set(chapters.map((c) => syntaxKey(c.syntax))).size === 1)
    findings.push({ rule: "syntax_clash", severity: "warning",
      message: "Every chapter uses the same SAY syntax.",
      hint: "Vary the syntax between chapters (e.g. SYA, ASA, YAA) to avoid a repetitive book." });
  else
    for (let i = 2; i < chapters.length; i++) {
      const k = syntaxKey(chapters[i].syntax);
      if (k === syntaxKey(chapters[i - 1].syntax) && k === syntaxKey(chapters[i - 2].syntax)) {
        findings.push({ rule: "syntax_clash", severity: "info", chapter: chapters[i].number,
          message: `Chapters ${chapters[i - 2].number}-${chapters[i].number} repeat the same syntax.`,
          hint: "Consider varying the SAY strings across consecutive chapters." });
        break;
      }
    }

  return {
    findings,
    manualReview: [
      "Does the Main Sentence column read as one continuous argument from top to bottom? (not checked automatically)",
      "Do the sentences in each chord belong to that chord's ARC stage? (not checked automatically)",
    ],
  };
}
