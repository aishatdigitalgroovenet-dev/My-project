// Single source of truth for the three client plans (SAYBOOK App MVP.docx, p.1).
// Nothing else in the codebase may hardcode chapter counts, wish limits or prices.

export type ChordKey = "awareness" | "resolution" | "callToAction";
export const CHORD_ORDER: readonly ChordKey[] = ["awareness", "resolution", "callToAction"];

export type ArcDistribution = Readonly<Record<ChordKey, number>>;
export type PlanId = "basic" | "standard" | "founding";

export interface Entitlement {
  kind: "ebook" | "mini_course" | "masterclass" | "app_discount" | "feedback";
  slug: string;
  title: string; // titles come from the client's plan list; the content itself is NOT provided yet
  quantity?: number;
}

export interface PlanConfig {
  id: PlanId;
  name: string;
  priceUsd: number;
  revisedWishes: number;
  arc: ArcDistribution; // default distribution
  customizableArc: boolean; // founding only; total must stay equal to the plan's chapter count
  editablePdf: true;
  founderCap?: number;
  entitlements: readonly Entitlement[];
}

const ebook = (slug: string, title: string): Entitlement => ({ kind: "ebook", slug, title });

export const PLANS: Readonly<Record<PlanId, PlanConfig>> = {
  basic: {
    id: "basic", name: "Basic", priceUsd: 59, revisedWishes: 1,
    arc: { awareness: 1, resolution: 3, callToAction: 1 },
    customizableArc: false, editablePdf: true,
    entitlements: [
      ebook("say-point-theory", "SAY Point Theory"),
      ebook("say-what-you-mean", "SAY What You Mean"),
      { kind: "mini_course", slug: "mini-course", title: "Mini course", quantity: 1 },
    ],
  },
  standard: {
    id: "standard", name: "Standard", priceUsd: 79, revisedWishes: 2,
    arc: { awareness: 2, resolution: 3, callToAction: 2 },
    customizableArc: false, editablePdf: true,
    entitlements: [
      ebook("just-say-it", "Just SAY It"),
      ebook("say-what-you-mean", "SAY What You Mean"),
      ebook("say-point-theory", "SAY Point Theory"),
      { kind: "mini_course", slug: "mini-course", title: "Mini courses", quantity: 2 },
    ],
  },
  founding: {
    id: "founding", name: "Founding Member", priceUsd: 199, revisedWishes: 3,
    arc: { awareness: 3, resolution: 4, callToAction: 2 },
    customizableArc: true, editablePdf: true, founderCap: 50,
    entitlements: [
      ebook("say-point-theory", "SAY Point Theory"),
      ebook("say-point-writing", "SAY Point Writing"),
      ebook("say-point-lattice", "SAY Point Lattice"),
      ebook("say-what-you-mean", "SAY What You Mean"),
      ebook("say-it-with-style", "SAY It With Style"),
      ebook("just-say-it", "Just SAY It"),
      { kind: "masterclass", slug: "grand-masterclass", title: "Grand Masterclass" },
      { kind: "app_discount", slug: "lifetime-discount", title: "Lifetime discount on SAYBOOK App" },
      { kind: "feedback", slug: "feature-suggestions", title: "Feature suggestions/comments", quantity: 3 },
    ],
  },
};

export const totalChapters = (arc: ArcDistribution): number =>
  CHORD_ORDER.reduce((n, k) => n + arc[k], 0);

export const arcLabel = (arc: ArcDistribution) => CHORD_ORDER.map((k) => arc[k]).join("-");

/**
 * Matrix = (largest chord) rows x 3 chords. INFERENCE, to be confirmed with the client:
 * 1-3-1 and 2-3-2 give 3x3 and 3-4-2 gives 4x3, which matches the client's stated matrices.
 */
export const matrixOf = (arc: ArcDistribution) => ({
  rows: Math.max(...CHORD_ORDER.map((k) => arc[k])),
  cols: 3 as const,
});

/** Validates a (possibly customised) ARC against a plan. Returns error strings; empty means valid. */
export function validateArc(plan: PlanConfig, arc: ArcDistribution): string[] {
  const errors: string[] = [];
  const target = totalChapters(plan.arc);
  for (const k of CHORD_ORDER) {
    if (!Number.isInteger(arc[k]) || arc[k] < 1) errors.push(`${k} needs at least 1 chapter`);
  }
  if (totalChapters(arc) !== target)
    errors.push(`Total chapters must be exactly ${target} for ${plan.name}`);
  if (!plan.customizableArc && CHORD_ORDER.some((k) => arc[k] !== plan.arc[k]))
    errors.push(`${plan.name} has a fixed ARC of ${arcLabel(plan.arc)}`);
  return errors;
}
