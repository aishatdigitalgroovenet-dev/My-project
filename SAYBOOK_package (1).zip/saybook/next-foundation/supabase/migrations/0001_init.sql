-- SAYBOOK initial schema. UNTESTED against a live Postgres so far (no DB in the build sandbox).
-- Source of truth for plan numbers is src/config/plans.ts; the seed below must match it.

create extension if not exists "pgcrypto";

create or replace function public.touch_updated_at() returns trigger language plpgsql as $$
begin new.updated_at = now(); return new; end $$;

-- ---------- Profiles ----------
create table public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  display_name text,
  created_at timestamptz not null default now()
);

create or replace function public.handle_new_user() returns trigger
language plpgsql security definer set search_path = public as $$
begin insert into public.profiles(id, display_name) values (new.id, new.raw_user_meta_data->>'display_name'); return new; end $$;
create trigger on_auth_user_created after insert on auth.users
  for each row execute function public.handle_new_user();

-- ---------- Plans & purchases ----------
create table public.plans (
  id text primary key check (id in ('basic','standard','founding')),
  name text not null,
  price_usd_cents integer not null,
  revised_wishes smallint not null,
  total_chapters smallint not null,
  default_arc jsonb not null,            -- {"awareness":1,"resolution":3,"callToAction":1}
  customizable_arc boolean not null default false,
  founder_cap integer
);
insert into public.plans values
 ('basic','Basic',5900,1,5,'{"awareness":1,"resolution":3,"callToAction":1}',false,null),
 ('standard','Standard',7900,2,7,'{"awareness":2,"resolution":3,"callToAction":2}',false,null),
 ('founding','Founding Member',19900,3,9,'{"awareness":3,"resolution":4,"callToAction":2}',true,50);

create table public.plan_entitlements (
  id uuid primary key default gen_random_uuid(),
  plan_id text not null references public.plans(id),
  kind text not null check (kind in ('ebook','mini_course','masterclass','app_discount','feedback')),
  slug text not null,
  title text not null,
  quantity integer,
  content_url text,                      -- empty until the client supplies real content
  unique (plan_id, kind, slug)
);

create table public.user_plans (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  plan_id text not null references public.plans(id),
  status text not null default 'active' check (status in ('active','upgraded','refunded')),
  upgraded_from uuid references public.user_plans(id),
  payment_ref text,                      -- provider reference once a payment provider is confirmed
  purchased_at timestamptz not null default now()
);
create index on public.user_plans(user_id);

-- Hard cap of founder_cap founding members, race-safe via advisory lock.
create or replace function public.enforce_founder_cap() returns trigger language plpgsql as $$
declare cap integer; taken integer;
begin
  select founder_cap into cap from public.plans where id = new.plan_id;
  if cap is not null then
    perform pg_advisory_xact_lock(hashtext('founder_cap'));
    select count(*) into taken from public.user_plans where plan_id = new.plan_id and status = 'active';
    if taken >= cap then raise exception 'Founding Member places are sold out'; end if;
  end if;
  return new;
end $$;
create trigger user_plans_founder_cap before insert on public.user_plans
  for each row execute function public.enforce_founder_cap();

-- ---------- Books ----------
create table public.books (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  user_plan_id uuid not null references public.user_plans(id),
  title text not null check (length(trim(title)) > 0),
  description text,
  audience text,
  theme text,
  status text not null default 'draft' check (status in ('draft','in_progress','complete')),
  matrix_rows smallint not null,
  matrix_cols smallint not null default 3,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique (id, user_id)
);
create index on public.books(user_id);
create trigger books_touch before update on public.books for each row execute function public.touch_updated_at();

-- Main Outline Wish (revision_no = 0) and its revised wishes (1..plan.revised_wishes)
create table public.wishes (
  id uuid primary key default gen_random_uuid(),
  book_id uuid not null references public.books(id) on delete cascade,
  revision_no smallint not null check (revision_no >= 0),
  body text not null,
  created_at timestamptz not null default now(),
  unique (book_id, revision_no)
);
create or replace function public.enforce_wish_limit() returns trigger language plpgsql as $$
declare lim smallint;
begin
  select p.revised_wishes into lim from public.books b
    join public.user_plans up on up.id = b.user_plan_id join public.plans p on p.id = up.plan_id
   where b.id = new.book_id;
  if new.revision_no > lim then raise exception 'Revised wish limit (%) reached for this plan', lim; end if;
  return new;
end $$;
create trigger wishes_limit before insert on public.wishes for each row execute function public.enforce_wish_limit();

-- ---------- DHM structure ----------
create table public.chords (
  id uuid primary key default gen_random_uuid(),
  book_id uuid not null references public.books(id) on delete cascade,
  key text not null check (key in ('awareness','resolution','callToAction')),
  position smallint not null,
  capacity smallint not null check (capacity >= 1),
  unique (book_id, key), unique (id, book_id)
);
-- chord capacities may never exceed the plan's total chapters
create or replace function public.enforce_chord_capacity() returns trigger language plpgsql as $$
declare total_allowed smallint; total_now integer;
begin
  select p.total_chapters into total_allowed from public.books b
    join public.user_plans up on up.id = b.user_plan_id join public.plans p on p.id = up.plan_id
   where b.id = new.book_id;
  select coalesce(sum(capacity),0) into total_now from public.chords where book_id = new.book_id and id <> new.id;
  if total_now + new.capacity > total_allowed then
    raise exception 'Chord capacities exceed the % chapters included in this plan', total_allowed; end if;
  return new;
end $$;
create trigger chords_capacity before insert or update on public.chords
  for each row execute function public.enforce_chord_capacity();

create table public.chapters (
  id uuid primary key default gen_random_uuid(),
  book_id uuid not null references public.books(id) on delete cascade,
  chord_id uuid not null,
  number smallint not null,
  title text not null default '',
  main_sentence text not null default '',      -- Story of Thesis: Main Sentence
  syntax jsonb not null default '[["S","Y","A"]]',  -- e.g. [["S","Y","A"],["A","S","A"],["Y","A","A"]]
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique (book_id, number), unique (id, book_id),
  foreign key (chord_id, book_id) references public.chords(id, book_id) on delete cascade,
  check (jsonb_typeof(syntax) = 'array')
);
create trigger chapters_touch before update on public.chapters for each row execute function public.touch_updated_at();
create or replace function public.enforce_chapter_capacity() returns trigger language plpgsql as $$
declare cap smallint; n integer;
begin
  select capacity into cap from public.chords where id = new.chord_id;
  select count(*) into n from public.chapters where chord_id = new.chord_id and id <> new.id;
  if n + 1 > cap then raise exception 'This chord is full (% chapters)', cap; end if;
  return new;
end $$;
create trigger chapters_capacity before insert or update of chord_id on public.chapters
  for each row execute function public.enforce_chapter_capacity();

create table public.main_advice (            -- Grand Advice: Main Advice Statements
  id uuid primary key default gen_random_uuid(),
  book_id uuid not null,
  chapter_id uuid not null,
  position smallint not null default 0,
  body text not null default '',
  foreign key (chapter_id, book_id) references public.chapters(id, book_id) on delete cascade
);

create table public.subheadings (
  id uuid primary key default gen_random_uuid(),
  book_id uuid not null,
  chapter_id uuid not null,
  position smallint not null default 0,
  title text not null default '',
  sub_sentence text not null default '',
  unique (id, book_id),
  foreign key (chapter_id, book_id) references public.chapters(id, book_id) on delete cascade
);

create table public.say_points (
  id uuid primary key default gen_random_uuid(),
  book_id uuid not null,
  subheading_id uuid not null,
  position smallint not null default 0,
  micro_sentence text not null default '',
  syntax jsonb not null default '["S","Y","A"]',
  unique (id, book_id),
  foreign key (subheading_id, book_id) references public.subheadings(id, book_id) on delete cascade
);

create table public.say_components (         -- Story / Yielded Evidence / Advice, one row per slot
  id uuid primary key default gen_random_uuid(),
  book_id uuid not null,
  say_point_id uuid not null,
  slot smallint not null check (slot between 0 and 2),
  kind char(1) not null check (kind in ('S','Y','A')),
  content text not null default '',
  unique (say_point_id, slot),
  foreign key (say_point_id, book_id) references public.say_points(id, book_id) on delete cascade
);

create table public.exports (
  id uuid primary key default gen_random_uuid(),
  book_id uuid not null references public.books(id) on delete cascade,
  user_id uuid not null references auth.users(id) on delete cascade,
  format text not null default 'editable_pdf',
  created_at timestamptz not null default now()
);

-- ---------- Row Level Security ----------
create or replace function public.owns_book(b uuid) returns boolean
language sql stable security definer set search_path = public as $$
  select exists (select 1 from public.books where id = b and user_id = auth.uid()) $$;

alter table public.profiles enable row level security;
create policy profiles_own on public.profiles for all using (id = auth.uid()) with check (id = auth.uid());

alter table public.plans enable row level security;
create policy plans_read on public.plans for select to authenticated, anon using (true);
alter table public.plan_entitlements enable row level security;
create policy ent_read on public.plan_entitlements for select to authenticated using (true);

alter table public.user_plans enable row level security;   -- insert/update only via service role (payment webhook)
create policy user_plans_read on public.user_plans for select using (user_id = auth.uid());

alter table public.books enable row level security;
create policy books_select on public.books for select using (user_id = auth.uid());
create policy books_insert on public.books for insert with check (
  user_id = auth.uid() and exists (select 1 from public.user_plans up where up.id = user_plan_id and up.user_id = auth.uid() and up.status = 'active'));
create policy books_update on public.books for update using (user_id = auth.uid()) with check (user_id = auth.uid());
create policy books_delete on public.books for delete using (user_id = auth.uid());

do $$ declare t text; begin
  foreach t in array array['wishes','chords','chapters','main_advice','subheadings','say_points','say_components'] loop
    execute format('alter table public.%I enable row level security', t);
    execute format('create policy %I on public.%I for all using (public.owns_book(book_id)) with check (public.owns_book(book_id))', t || '_owner', t);
  end loop;
end $$;

alter table public.exports enable row level security;
create policy exports_own on public.exports for all using (user_id = auth.uid() and public.owns_book(book_id))
  with check (user_id = auth.uid() and public.owns_book(book_id));
