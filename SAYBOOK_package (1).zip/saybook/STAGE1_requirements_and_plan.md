# SAYBOOK — Stage 1: Requirements & Architecture

Legend: **[Client]** = stated in SAYBOOK App MVP.docx (23 pp.). **[Rec]** = my recommendation. **[Inferred]** = deduced, needs confirmation.

## 1. Understanding of the product
The MVP is a working **Double Helix Map (DHM)**: a book-outline generator where the **Grand Narrative** (Story of Thesis, SOT) and **Grand Advice** (Main Advice Statements) are planned side by side, chapter by chapter, across three **Chords** (A / R / C) before any manuscript is written **[Client]**. The client also sells three one-time-looking packages (Basic $59, Standard $79, Founding $199) bundling DHM limits with e-books, mini-courses and a masterclass **[Client]**. The "SAY BOOK App" itself is labelled "Coming Soon", and the demo video and slides will be supplied later **[Client]**.

## 2. DHM as software functionality
| Concept [Client] | Software behaviour |
|---|---|
| Main Outline Wish + revised wishes | `wishes` rows, revision 0 = main, 1..N = revisions, N capped by plan |
| Chords (A, R, C) | 3 `chords` per book, each with a `capacity` derived from the plan's ARC |
| Story of Thesis | Chapter Main Sentence, subheading Sub-Sentence, SAY point Micro-Sentence |
| Chapter (String) Syntax, e.g. SYA+ASA+YAA | Structured `syntax` JSON (array of S/Y/A triples) with presets and validation |
| Main Advice Statements | `main_advice` rows per chapter (one or more) |
| SAY module (200–300 words when written) | `say_points` + 3 `say_components`; outline holds short notes only |
| DHM as diagnostic | Rule-based audit (`src/lib/dhm/audit.ts`), see §7 of the roadmap |
| Read the SOT top to bottom | "SOT chain" view: all Main Sentences in order as continuous prose |
| 3×3 / 4×3 matrix | Derived `rows = largest chord`, `cols = 3` [Inferred] |
| Editable PDF | Dedicated PDF layout with fillable fields [Rec] |

## 3. Architecture [Rec]
Next.js (App Router) + TypeScript strict + Tailwind; Supabase (Postgres, Auth, RLS); server actions validated with Zod; PDF via `pdf-lib` (supports real AcroForm fillable fields); Vercel. Plan numbers live only in `src/config/plans.ts`. DHM edits are autosaved per field (debounced) with a visible Saved / Saving / Error indicator and a `beforeunload` guard.

## 4. Folder structure
```
src/app/(marketing)/        landing, pricing
src/app/(auth)/             login, register, forgot/reset password
src/app/(app)/dashboard     project list, plan, settings
src/app/(app)/books/new     guided creation
src/app/(app)/books/[id]/   dhm (workspace), chain (SOT review), audit, export
src/components/{ui,marketing,dhm}/
src/config/plans.ts         DONE
src/lib/dhm/{types,syntax,audit}.ts   DONE; later: persistence.ts, pdf.tsx
src/lib/supabase/{client,server}.ts
supabase/migrations/        0001_init.sql DONE (untested on live Postgres)
```

## 5. Database
See `supabase/migrations/0001_init.sql`. Hierarchy: `books → chords → chapters → subheadings → say_points → say_components`, plus `main_advice`, `wishes`, `plans`, `plan_entitlements`, `user_plans`, `exports`. Every child carries `book_id` with composite foreign keys so a row can never point at another user's parent; RLS uses `owns_book(book_id)`. Triggers enforce the revised-wish limit, chord capacity, chapters-per-chord and the 50-founder cap. `user_plans` is writable only by the service role (payment webhook).

## 6. Plans
| | Basic $59 | Standard $79 | Founding $199 |
|---|---|---|---|
| ARC (A-R-C) | 1-3-1 | 2-3-2 | 3-4-2, customizable |
| Chapters | 5 | 7 | 9 |
| Matrix | 3×3 | 3×3 | 4×3 |
| Revised wishes | 1 | 2 | 3 |
| E-books | 2 | 3 | 6 |
| Courses | 1 mini | 2 mini | Grand Masterclass |
| Extras | | | lifetime app discount, 3 feature suggestions, 50 places |

## 7. Pages and roadmap
Pages: `/` · `/pricing` · `/login` `/register` `/forgot-password` · `/dashboard` · `/books/new` · `/books/[id]` (DHM workspace) · `/books/[id]/chain` · `/books/[id]/audit` · `/books/[id]/export` · `/account`.
Roadmap: (1) foundation + design tokens [next], (2) DHM engine with in-memory state, (3) Supabase persistence + auth, (4) dashboard + creation, (5) PDF export, (6) landing + pricing, (7) entitlements, payments only after confirmation, (8) testing across all three plans.
Order note [Rec]: the brief lists marketing first, but building the DHM engine before the landing page matches "DHM first".

## 8. Inconsistencies found in the client document
1. **Example DHM has 8 chapters (3-3-2); no plan uses that.** Plans are 1-3-1, 2-3-2, 3-4-2.
2. **Chord descriptions conflict.** Text says Chord 3 = "Identity/Essential shift"; the ARC table calls it the "Operational Problem". Awareness Chapter 3 ("Identity Crisis") previews the CTA problem, so a keyword-based ARC check would misfire.
3. **Chapter 3's Main Sentence says "collaboration"; the combined paragraph says "creativity".**
4. **SAY point numbering breaks.** The worked example numbers points "1 & 2", "3 & 4", "4 & 5" with pours P1, P2, P3, P4, P6, P7 (P5 skipped), and one micro-sentence covers two points, while Chapter 1 uses one sentence per point.
5. **What is a "SAY point"?** In Chapter 1 each point is a unit with its own sentence; in the "Pour", each P is a single S, Y or A element; elsewhere a "Mixed Point" contains all three.
6. **Chapter syntax vs. point counts.** SYA+ASA+YAA is 3 strings (9 elements), but each chapter in the example has 2 sub-sentences × 3 points = 6.
7. "Revised wish", "Upgrade in 10 mins", "customizable" and the matrix sizes are never defined. Basic omits the upgrade line.
8. The document reads partly as an AI chat transcript (reflective questions addressed to the client); I treated those as noise.

## 9. Decisions that need the client
1. **Is the DHM generated from the wish (AI) or filled in manually?** "Outline generator" and "revised wish" suggest generation; your brief says no AI. Biggest scope question.
2. What exactly is a revised wish: a rewrite of the wish text, a regeneration, or a restart? Per book or per account? Which one is "current"?
3. How many books can one purchase create?
4. One-time purchase or subscription? (The document shows one-time prices and a future paid app.)
5. "Upgrade in 10 mins": 10 minutes from purchase? Does it apply to every plan change? Refund or credit mechanics?
6. Founding "customizable ARC": any split of 9 chapters with at least 1 per chord? (I assumed yes.)
7. Matrix meaning (my inference: largest chord × 3).
8. SAY point definition and how syntax strings map to points (items 5–6 above). My recommended model: a point is one S/Y/A triple; chapter syntax is the default for new points.
9. Editable PDF: blank template, filled-in outline, or both? (Recommend filled-in with fillable fields.)
10. Payment provider, tax/VAT handling, refunds, and where e-books/courses will be hosted.
11. ARC alignment: acceptable for the author to tag each chapter's problem layer (Contextual / Methodological / Operational) so the audit can compare it with the chord? (Rec; otherwise this check stays manual.)
