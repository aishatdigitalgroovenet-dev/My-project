# SAYBOOK package

## website/index.html
The complete SAYBOOK website: landing page plus the working Double Helix Map workspace, in one self-contained file.
- Open it by double-clicking, or upload it to any static host (Netlify, Vercel, GitHub Pages, any web server).
- Projects are saved in the visitor's own browser only (no accounts, no cloud, no payments yet).
- "Download PDF" works inside Claude's viewer; on your own host, use the Print button and choose Save as PDF.
- Fonts load from Google Fonts when online; the page falls back to system fonts offline.

## next-foundation/
Starting files for the full Next.js + Supabase version (not a runnable app yet; run create-next-app first, then copy these in):
- src/config/plans.ts        the three plans (single source of truth)
- src/lib/dhm/               types, SAY syntax model, audit rules
- supabase/migrations/       database schema with row-level security (not yet run against a live database)
- .env.example               environment variables (payments left blank)

## STAGE1_requirements_and_plan.md
Requirements analysis, inconsistencies found in the client document, and the open client decisions.
